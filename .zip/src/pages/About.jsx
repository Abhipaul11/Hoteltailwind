import React, { useEffect } from 'react'
import styles from './pagecss/About.module.css'
import { MdHiking, MdNaturePeople } from "react-icons/md";
import { HashLink } from 'react-router-hash-link';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import AOS from 'aos';
import 'aos/dist/aos.css';

function About() {
    useEffect(() => {
        AOS.init({ duration: 400 }); // Initialize AOS with animation duration
    }, []);

    return (
        <>
            <Navbar />
            <div data-aos="slide-right">

                <section id='aboutpage'>
                    <div className={styles.about_part}>

                        <div className={styles.abt}>
                            <div className={styles.abtimages}>
                                <img src="/images/view.jpg" alt="" className={styles.abtimg1} />
                            </div>
                            <div className={styles.abtfirsttext}>
                                <h2 className={styles.aboutus}>About <span style={{ color: "brown", fontStyle: "italic" }}>Shanti Group</span></h2>
                                <p>"We offers seamless hotel bookings across North Bengal, ensuring comfortable stays and unforgettable experiences in the region's most scenic destinations."</p>
                            </div>
                        </div>


                        <div className={styles.about_container}>
                            <div className={styles.about_content}>
                                <h2>About Shanti Inn</h2>
                                <p>1. Jhandi is a small hamlet situated 6,200 feet above sea level, nestled in the serene hills of Jhandi, Kalimpong. Around 10 kilometers from Lava, our hotel offers a perfect blend of modern luxury and warm hospitality. Whether you're seeking a peaceful retreat, a business trip, or a special celebration in Jhandi, our hotel offers the perfect setting.The hotel features well-appointed rooms with breathtaking views of the surrounding hills</p> <p>2. In addition  we also offer booking services for other properties in the region check it from other places. We can arrange the perfect accommodation to suit your needs. Our extensive network ensures you have a variety of options to choose from, all with our trusted quality and service.</p>
                                <p>3. We are delighted to offer exclusive travel packages to some of the most scenic and serene destinations We also provide easy booking options for a variety of properties, including our own Shanti Inn in Jhandi, Kalimpong. Let us help you make your travel dreams come true!"</p>


                                <div className={styles.button}>
                                    <HashLink smooth to='/#homepage'><button className={styles.btn1}>Book now</button></HashLink>
                                </div>
                            </div>

                            <div className={styles.about_images}>
                                <img src="/images/download.jpg" alt="" />
                                <img src="/images/food.jpg" alt="" />
                            </div>
                        </div>
                    </div>

                    <div className={styles.secondpart} >
                        <div className={styles.heading}>
                            <h3>Our Sevices</h3>
                            <div style={{ width: '100%', display: "flex", justifyContent: "center" }}>
                                <div style={{ width: '10rem', backgroundColor: 'red', padding: '1px', textAlign: "center" }}> </div>
                            </div>
                        </div>
                        <div className={styles.container}>
                            <div className={styles.box}>
                                <img src="/images/png1.png" alt="" />
                                <p>Sightseeing service</p>
                                <span>Would you prefer a half-day city tour or a full day exploring Kalimpong? Let us know your preference, and we’ll adjust your itinerary to ensure a memorable and well-managed experience tailored to you!</span>
                            </div>
                            <div className={styles.box}>
                                <img src="/travelpics/png1.png" alt="" />
                                <p>Travel Packages</p>
                                <span>Discover best travel packages that take you through the stunning landscapes of India, Nepal, Bhutan, Sikkim, and more.We have the perfect itinerary for you.</span>
                            </div>
                            <div className={styles.box}>
                                <img src="/images/png2.png" alt="" />
                                <p>Amidst Nature</p>
                                <span>Nestled in the tranquil hills of Jhandi, Kalimpong, our location provides breathtaking views of rolling landscapes and majestic peaks. Immerse yourself in nature's beauty, enjoy serene surroundings.</span>
                            </div>
                            <div className={styles.box}>
                                <img src="/images/png3.jpeg" alt="" />
                                <p>"Delicious Local food"</p>
                                <span>Best freshly prepared delicious and traditional dishes, offering an authentic taste of the region’s rich culinary heritage.</span>
                            </div>
                            <div className={styles.box}>

                                <MdHiking size={40} color='red' />
                                <p>Activities </p>
                                <span>Enjoy cozy bonfire evenings, perfect for connecting with nature. Relax and unwind under the stars, sharing stories and experiencing the peaceful ambiance of the surrounding wilderness.</span>
                            </div>

                        </div>
                    </div>
                </section>
            </div>
            <Footer />
        </>
    )
}

export default About;