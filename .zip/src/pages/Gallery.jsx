import React, { useState } from 'react';
import styles from './pagecss/Gallery.module.css';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Banner from '../pagecomponents/Banner';


function Gallery() {


    return (
        <>
            <Navbar />

            <div className={styles.imagecontainer}>
                <img src="/jhandi/jpic1.jpg" alt="" />
                <img src="/jhandi/jpic2.jpg" alt="" />
                <img src="/jhandi/jpic3.jpg" alt="" />
                <img src="/jhandi/jpic4.jpg" alt="" />


                <img src="/ramdhura/t5.jpg" alt="" />
                <img src="/ramdhura/t1.jpg" alt="" />
                <img src="/ramdhura/t2.jpg" alt="" />


            </div>
            <Footer />
        </>
    );
}



export default Gallery;
