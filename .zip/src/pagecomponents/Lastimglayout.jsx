import React, { useEffect } from 'react'
import styles from './pagecomponentcss/lastimglayout.module.css'
import { Link } from 'react-router-dom'
import { IoIosArrowRoundForward } from "react-icons/io";
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import ImageListItemBar from '@mui/material/ImageListItemBar';
import AOS from 'aos';
import 'aos/dist/aos.css';

function Lastimglayout() {

    useEffect(() => {
        AOS.init({ duration: 200 }); // Initialize AOS with animation duration
    }, []);
    return (
        <>
            <div data-aos="slide-right">

                <div className={styles.outside}>
                    <p>Travel Packages</p>
                    <Link to="/travelpackage" className={styles.link}>View all<IoIosArrowRoundForward className={styles.rightarrow} /></Link>
                </div>

                <div className={styles.main}>
                    <ImageList sx={{ width: 800, height: 450, margin: "20px 5px" }}>
                        {itemData.map((item) => (
                            <ImageListItem key={item.img}>
                                <img
                                    srcSet={`${item.img}?w=248&fit=crop&auto=format&dpr=2 2x`}
                                    src={`${item.img}?w=248&fit=crop&auto=format`}
                                    alt={item.title}
                                    loading="lazy"
                                />
                                <ImageListItemBar title={item.title} />
                            </ImageListItem>
                        ))}
                    </ImageList>

                </div >
            </div>

        </>
    )
}

const itemData = [

    {
        img: '/images/kashmir.jpg',
        title: 'Kashmir',
        rows: 2,
        cols: 2,
    },
    {
        img: '/images/ladakh.jpg',
        title: 'Ladakh',
        rows: 2,
        cols: 2,
    },
    {
        img: '/images/arunachal.jpg',
        title: 'Arunachal pradesh',
        rows: 3,
        cols: 2,
        featured: true,
    },
    {
        img: '/images/manali.jpg',
        title: 'Manali',
        rows: 2,
        cols: 2,
    },
    {
        img: '/images/simla.jpg',
        title: 'Shimla',
        rows: 2,
        cols: 2,
    },
    {
        img: '/travelpics/sikkim.jpg',
        title: 'Sikkim',
        rows: 2,
        cols: 2,
    },
];

export default Lastimglayout