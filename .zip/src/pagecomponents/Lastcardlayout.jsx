import React, { useEffect } from 'react'
import styles from './pagecomponentcss/lastcardlayout.module.css'
import AOS from 'aos';
import 'aos/dist/aos.css';

function Lastcardlayout() {
    const handleShare = () => {
        if (navigator.share) {
            // Use the Web Share API
            navigator
                .share({
                    title: document.title,
                    text: "Check-out this page! they provide room bookings in and offer travel packages!",
                    url: window.location.href,
                })
                .then(() => console.log("Page shared successfully!"))
                .catch((error) => console.error("Error sharing page:", error));
        } else {
            // Fallback for unsupported browsers
            const pageLink = window.location.href;
            navigator.clipboard.writeText(pageLink).then(() => {
                alert("Page link copied to clipboard! Share it with others.");
            });
        }
    };

    useEffect(() => {
        AOS.init({ duration: 400 }); // Initialize AOS with animation duration
    }, []);
    return (
        <>
            <div className={styles.layoutcardheading}>
                <h3>Also Explore  <span style={{
                    color: "red", fontStyle: "italic", marginLeft: '2px'
                }}> Other services</span> </h3>
                <p>Discover amazing travel packages, cozy accommodations, Conference hall for bussiness meetings</p>
            </div>

            <div className={styles.main}>
                <div className={styles.insidemain}>
                    <div data-aos="flip-right">
                        <div className={`${styles.layoutcard} ${styles.layoutcard1}`}>
                            <img src="/images/rishop.jpg" alt="" className={styles.img} />
                            <div className={styles.layoutcardtext}>
                                <p>Plan your perfect  customized travel packages, offering exciting activities and best experiences.</p>
                                <div className={styles.btngrp}>
                                    <button onClick={handleShare}>Share</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div data-aos="flip-right">
                        <div className={`${styles.layoutcard} ${styles.layoutcard2}`}>
                            <img src="/images/paragliding.jpg" alt="" />
                            <div className={styles.layoutcardtext}>
                                <p>We offer business meetings in conference halls at Jhandi and beyond</p>
                                <div className={styles.btngrp}>
                                    <a href={`https://wa.me/918240913778?text=${encodeURIComponent("I want to book a conference hall for a business meeting."
                                    )}`} target="_blank" rel="noopener noreferrer" className={styles.whatsappLink}  > Contact </a>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div data-aos="flip-right">
                        <div className={`${styles.layoutcard} ${styles.layoutcard3}`}>
                            <img src="/images/room.jpg" alt="" />
                            <div className={styles.layoutcardtext}>
                                <p>Relax in our premium hotel rooms in jhandi and in other's places ramdhura,sittong  more...</p>
                                <div className={styles.btngrp}>
                                    <button onClick={handleShare}>Share</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div className={styles.bottomtext}>
                    <p style={{ fontSize: "1.5rem", fontWeight: "300", fontFamily: 'Poppins', color: "white" }}> Embark on Your Dream Journey Today! </p>
                    <button>Know more</button>
                </div>
            </div>
        </>
    )
}

export default Lastcardlayout

