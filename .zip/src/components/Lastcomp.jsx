import React from 'react'
import styles from './componentcss/lastcomp.module.css'
import { Link } from 'react-router-dom'
import { IoIosArrowRoundForward } from "react-icons/io";

function Lastcomp() {
    return (
        <>
            <div style={{ padding: '30px', backgroundColor: "#f9f9f9" }}>

                <div className={styles.lastcompfirst}>
                    <p className={styles.firstp}>Services</p>
                    <Link to='/aboutpage' className={styles.secondp}> View All <IoIosArrowRoundForward className={styles.rightarrow} /> </Link>
                </div>

                <div className={styles.lastcompcontainer}>
                    <div className={styles.leftbar}>
                        <div className={styles.option}>
                            <div className={styles.icon}>🏊</div>
                            <div className={styles.text}>
                                <h4>Bonfire</h4>
                                <p>Relax and enjoy the bonfire</p>
                            </div>
                        </div>

                        <div className={styles.option}>
                            <div className={styles.icon}>🌱</div>
                            <div className={styles.text}>
                                <h4>Nature View</h4>
                                <p>Bask in serene greenery and fresh air</p>
                            </div>
                        </div>

                        <div className={styles.option}>
                            <div className={styles.icon}>🍴</div>
                            <div className={styles.text}>
                                <h4>Top Foods</h4>
                                <p>Delicious meals: Breakfast, Lunch, and Dinner</p>
                            </div>
                        </div>

                        <div className={styles.option}>
                            <div className={styles.icon}>💼</div>
                            <div className={styles.text}>
                                <h4>Best Conference Hall</h4>
                                <p>Host your meetings with a cool view</p>
                            </div>
                        </div>
                    </div>

                    <div className={styles.imageContainer}>
                        <img className={styles.image} src="https://cdn.pixabay.com/photo/2021/10/11/18/58/lake-6701636_1280.jpg" alt="" />
                        {/* <video src="https://videos.pexels.com/video-files/3226171/3226171-sd_640_360_24fps.mp4" autoPlay muted loop></video> */}
                    </div>
                </div>
            </div>

        </>
    )
}

export default Lastcomp