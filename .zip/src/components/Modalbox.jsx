import React from 'react'
import styles from './componentcss/Modalbox.module.css';

function Modalbox({ isOpen, closeModal, title, content }) {
    if (!isOpen) return null;

    return (
        <div className={styles.modalOverlay}>
            <div className={styles.modalContent}>
                <h2>{title}</h2>
                <p>{content}</p>
                <button onClick={closeModal} className={styles.closeButton}>X</button>
            </div>
        </div>
    );
}

export default Modalbox;