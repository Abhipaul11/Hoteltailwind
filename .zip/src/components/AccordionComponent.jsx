import React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionActions from '@mui/material/AccordionActions';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import { colors } from '@mui/material';
import { Link } from 'react-router-dom';

// Styled AccordionContainer for width
const AccordionContainer = styled('div')({
    maxWidth: '800px',
    width: "90%",
    margin: "auto"
});

// Styled Accordion to override hover background color
const CustomAccordion = styled(Accordion)({
    '&:hover': {
        backgroundColor: 'transparent',
    },
});

// Styled AccordionSummary to prevent hover effect on span
const CustomAccordionSummary = styled(AccordionSummary)({
    '&:hover': {
        backgroundColor: 'transparent',
    },
});

// Styled Button to prevent hover effect on the button
const CustomButton = styled(Button)({
    '&:hover': {
        backgroundColor: 'black',
    },
});

function AccordionComponent() {
    return (
        <div style={{ backgroundColor: "#f8f9fa", padding: "4rem 0px " }}>
            <h3 style={{ textAlign: "center", marginBottom: "1rem" }}>Frequently Asked Questions</h3>
            <AccordionContainer>
                <CustomAccordion>
                    <CustomAccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1-content"
                        id="panel1-header"
                    >
                        <Typography component="span" sx={{ color: "black", textAlign: "left" }}>Room Prices in jhandi and other places</Typography>
                    </CustomAccordionSummary>
                    <AccordionDetails sx={{ fontFamily: "Poppins" }}>
                        The room prices are fixed, but the total cost can vary based on the amenities and services you choose. For more detailed information, it’s best to contact us directly.
                    </AccordionDetails>
                    <AccordionActions sx={{ justifyContent: "flex-start" }}>
                        <a href="https://wa.me/8240913778?text=I%20want%20to%20book%20room%20in%20Jhandi%20give%20me%20more%20details" target="_blank" rel="noopener noreferrer">
                            <CustomButton sx={{ backgroundColor: "blue", color: "white" }}>Book</CustomButton>
                        </a>
                    </AccordionActions>

                </CustomAccordion>

                <CustomAccordion>
                    <CustomAccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2-content"
                        id="panel2-header"
                    >
                        <Typography component="span" sx={{ color: "black", textAlign: "left" }}>Conference Hall Available, Pricing Depends on Requirements </Typography>
                    </CustomAccordionSummary>
                    <AccordionDetails sx={{ fontFamily: "Poppins" }}>
                        Shanti Inn Jhandi offers a conference hall for programs. Pricing depends on the number of attendees and the amenities you need. Please reach out for a personalized quote based on your event requirements.
                    </AccordionDetails>
                </CustomAccordion>

                <CustomAccordion defaultExpanded>
                    <CustomAccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel3-content"
                        id="panel3-header"
                    >
                        <Typography component="span" sx={{ color: "black", textAlign: "left" }}>Custom Travel Packages Available Across India</Typography>
                    </CustomAccordionSummary>
                    <AccordionDetails sx={{ fontFamily: "Poppins" }}>
                        We offer travel packages across India, including Kashmir, Nepal, Bhutan, Sikkim, Darjeeling, and more. Contact us for customized packages based on your destination and travel preferences.
                    </AccordionDetails>
                    <AccordionActions sx={{ justifyContent: "flex-start" }}>
                        <Link to="/travelpackage"><CustomButton sx={{ backgroundColor: "blue", color: "white" }}>View</CustomButton></Link>
                    </AccordionActions>
                </CustomAccordion>
            </AccordionContainer>
        </div >
    );
}

export default AccordionComponent;
